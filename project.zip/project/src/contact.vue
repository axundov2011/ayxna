<template>
<div>
<div class="contact contact-expand-lg haqqinda-light bg-light"></div>
<div class="container"></div>
<div class="row" >
    <div class="col-8 mx-auto mt-2 mb-5 mr-5">
        <img src="./assets/operator-blog.jpg" alt="">

    </div>

</div>

</div>

</template>

<script>
export default {
    setup() {
        
    },
}
</script>

<style scoped>

img{
  width: 900px;
   height: 400px;
  object-fit: cover;
  }

</style>