<template>
  <div>
    <div class="container">
      <div class="row">
        <div class="col-6">
          <form action="" class="pt-3">
            <input
                @blur="$v.email.$touch()"
              type="email"
              :class="{ 'is-invalid' : !$v.email.required , 'is-valid' : $v.email.required }"
              v-model="email"
          
              class="form-control"
              placeholder="Email daxil edin"
            />
           
            <small class="badge bg-danger" v-if="!$v.email.required" > Daxil etmek mecburidir </small>
       <small class="badge bg-danger" v-if="!$v.email.email" > Duzgun Mail daxil edin </small>

             <input
                @input="$v.password.$touch()"
              type="password"
              v-model="password"
              class="form-control mt-3"
              placeholder="password daxil edin"
            />
            <!-- :class="{ 'd-none' : $v.email.required , 'd-inline' : !$v.email.required }" -->
            <small class="badge bg-danger" v-if="!$v.password.required" > Daxil etmek mecburidir </small>
       <small class="badge bg-danger" v-if="!$v.password.numeric" > Yalniz number  daxil edin </small>
       <small class="badge bg-danger" v-if="!$v.password.minLength" > Minumum  {{ $v.password.$params.minLength.min }} reqem daxil et </small>
       <small class="badge bg-danger" v-if="!$v.password.maxLength" > Maksimum {{ $v.password.$params.maxLength.max }} reqem daxil et </small>

  <input
                @input="$v.repassword.$touch()"
              type="password"
              v-model="repassword"
              class="form-control mt-3"
              placeholder="password daxil edin"
            />
            <!-- :class="{ 'd-none' : $v.email.required , 'd-inline' : !$v.email.required }" -->
            <small class="badge bg-danger" v-if="!$v.repassword.required" > Daxil etmek mecburidir </small>
            <small class="badge bg-danger" v-if="!$v.repassword.numeric" > Yalniz number  daxil edin </small>
            <small class="badge bg-danger" v-if="!$v.repassword.minLength" > Minumum  {{ $v.repassword.$params.minLength.min }} reqem daxil et </small>
            <small class="badge bg-danger" v-if="!$v.repassword.maxLength" > Maksimum {{ $v.repassword.$params.maxLength.max }} reqem daxil et </small>
            <small class="badge bg-danger" v-if="!$v.repassword.sameAs" > Sifreler uygunlasmir </small>

 <input
                @input="$v.age.$touch()"
              type="number"
              v-model="age"
              class="form-control mt-3"
              placeholder="yas daxil edin"
            />
            <!-- :class="{ 'd-none' : $v.email.required , 'd-inline' : !$v.email.required }" -->
            <small class="badge bg-danger" v-if="!$v.age.required" > Daxil etmek mecburidir </small>
            <small class="badge bg-danger" v-if="!$v.age.between" > Yalniz {{ $v.age.$params.between.min }}-{{ $v.age.$params.between.max }} arasi yas qebul edikrir </small>
          
<br>
<button class="btn btn-success mt-3 " :class="{ 'disabled' : $v.$invalid }" > Gonder </button>

          </form>
        </div>
        <div class="col-6">
          <p>{{ $v }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { required,email, numeric,minLength,maxLength,sameAs, between  } from "vuelidate/lib/validators";

export default {
  data() {
    return {
      email: null,
      password : null,
      repassword : null,
      age : null
    };
  },
  validations: {
    email: {
      required,
      email
    },
    password : {
      required,
      numeric,
      minLength : minLength(4),
      maxLength : maxLength(10)
    },
    repassword : {
        required,
      numeric,
      minLength : minLength(4),
      maxLength : maxLength(10),
      sameAs : sameAs("password")
    },
    age : {
      required,
      between : between(18,60)
    }
  },
};
</script>

<style>
</style>
