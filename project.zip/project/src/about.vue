<template>
<div class="haqqinda haqqinda-expand-lg haqqinda-light bg-light">
  <div class="container">
    <div class="row">
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
<h5 class="text-uppercase  mb-5 font-weight-bold text-warning"> Guncel Xeberler  </h5>
</div>
</div>



   <div class="row mb-5">
    
    
<div class="col-4">
  <div class="card ho">
        <div class="view ovrlay">
  <img src="./assets/site5.jpg" class="card-img-top" alt="...">
  </div>
  <div class="card-body">
    <h5 class="card-title">Son Dakika</h5>
    <p class="card-text">Çinli alimlər dərmanları orqanizmin lazımi yerlərinə çatdıra bilən 4D mikrobotları yaradıblar”.</p>
    <a href="#" class="btn btn-primary" style="background-color:#000000" >Daxil Ol</a>
  </div>
</div>
</div>


    
<div class="col-4">
      <div class="card ho">
        <div class="view ovrlay">
  <img src="./assets/mus.jpg" class="card-img-top" alt="...">
  </div>
  <div class="card-body">
    <h5 class="card-title">Son Dakika</h5>
    <p class="card-text">Dünya bazarında bu gün neftin qiymətində artım müşahidə olunub. Dünən isə “Brent”in iyul fyuçersləri ”</p>
    <a href="#" class="btn btn-primary" style="background-color:#000000" >Daxil Ol</a>
  </div>
</div>
</div>

<div class="col-4">
  <div class="card ho">
      
        <div class="view ovrlay">
  <img src="./assets/site.jpg" class="card-img-top" alt="...">
  </div>
  <div class="card-body">
    <h5 class="card-title">Son Dakika</h5>
    <p class="card-text">Texnologiyanın inkişafı, lazımsız təbəqə yaradacaq və həmin təbəqəyə kimlər daxil olacaq?:”.</p>
    <a href="#" class="btn btn-primary " style="background-color:#000000">Daxil Ol</a>
  </div>
</div>
</div>
</div>







 </div>

</div>
  
</template>

<script>
export default {

};
</script>

<style scoped>
img{
  max-width: 100%;
    height: 400px;
    object-fit: cover;
  
}

.ovrlay{
  overflow: hidden;
}

.card-img-top{
  transition: all 1s;
}

.card-img-top:hover{
    transform: scale(1.2,1.2)
}
button{
  background-color: cyan;
  height: 30px;
border-radius: 5px;
}

.card{
  background-color: rgb(106, 106, 112) !important;
}


</style>