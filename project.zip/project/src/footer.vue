<template>
<div>
    <footer class="bg-dark textw-white pt-5 pb-4">
<div class="container text-center text-md-left">
    <div class="row text-center text-md-left">
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
            <h5 class="text-uppercase md-4 font-weight-bold text-warning">Company Name</h5>
            <p><a href="#" class="text-white" style="text-decoration : none;">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Debitis officia, adipisci aliquam porro nobis accusantium ducimus vitae labore et commodi at eum consequuntur magnam ipsam deleniti sit odio architecto quam.</a></p>

        </div>
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
           <h5 class="text-uppercase md-4 font-weight-bold text-warning">Conty</h5>
           <p>
               <a href="#" class="text-white" style="text-decoration : none;">Theprovides</a>
               </p>


               <p>
               <a href="#" class="text-white" style="text-decoration : none;">Creatvy</a>
               </p>

               <p>
               <a href="#" class="text-white" style="text-decoration : none;">Sourcefiles</a>
               </p>
               <p>
               <a href="#" class="text-white" style="text-decoration : none;">Bootstrap 5 alph</a>
               </p>



        </div>


        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
            <h5 class="text-uppercase  mb-4 font-weight-bold text-warning">Useful Links</h5>
           <p>
               <a href="#" class="text-white" style="text-decoration : none;">Theprovides</a>
               </p>


               <p>
               <a href="#" class="text-white" style="text-decoration : none;">Your Accaunt</a>
               </p>

               <p>
               <a href="#" class="text-white" style="text-decoration : none;">Become an affiliates </a>
               </p>
               <p>
               <a href="#" class="text-white" style="text-decoration : none;">Shipping Rates</a>
               </p>

                              <p>
               <a href="#" class="text-white" style="text-decoration : none;">Help</a>
               </p>

        </div>
<div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
     <h5 class="text-uppercase  mb-4 font-weight-bold text-warning">Contact</h5>

     <p>
         <a href="#" class="text-white" style="text-decoration : none;"><i class="fas fa-home mr-3"></i>Azerbaijan, Baku</a>
         
         </p>

     <p>
         <a href="#" class="text-white" style="text-decoration : none;"><i class="fas fa-envelope mr-3"></i> ayxan.baku@gmail.com</a> 
     </p>
     <p>
         <a href="#" class="text-white" style="text-decoration : none;"><i class="fas fa-phone mr-3"></i>+994-70-317-03-00 </a>
     </p>
     <p>
        <a href="#" class="text-white" style="text-decoration : none;"><i class="fas fa-print mr-3"></i>New York, NY 2333, US</a> 
         </p>
     
</div>
</div>

<hr class="mb-4"> 
<div class="row align-items-center">
    <div class="col-md-7 col-lg-8">
       <p>
               <a href="#" class="text-white" style="text-decoration : none;">Copyright 2020 All rights reserved by:</a>
         <strong class="text-warning ">The Provides</strong>
         </p>
       
       

    </div>

</div>

</div>
    </footer>
    
                

</div>


</template>

<script>
export default {}
</script>

<style scoped>




</style>